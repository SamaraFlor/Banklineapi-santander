package br.com.nava1.banklineapi.model;

public enum MovimentacaoTipo {
	
	RECEITA,
	DESPESAS

}
