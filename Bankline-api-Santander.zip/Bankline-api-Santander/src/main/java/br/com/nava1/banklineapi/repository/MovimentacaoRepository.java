package br.com.nava1.banklineapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.nava1.banklineapi.model.Movimentacao;


@Repository
public interface MovimentacaoRepository extends JpaRepository<Movimentacao, Integer>{

}
